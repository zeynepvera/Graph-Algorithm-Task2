package com.mycompany.graphalgorithmtask2;

public class Edge {

    int to;
    int capacity;
    int cost;

    public Edge(int to, int capacity, int cost) {
        this.to = to;
        this.capacity = capacity;
        this.cost = cost;
    }

}
